﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Khamidova_A._2IP1_11_18
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите номер месяца: ");
            int n = int.Parse(Console.ReadLine());
            switch (n)
            {
                case 1:
                    Console.Write("Январь");
                    break;
                case 2:
                    Console.Write("Февраль");
                    break;
                case 3:
                    Console.Write("Март");
                    break;
                case 4:
                    Console.Write("Апрель");
                    break;
                case 5:
                    Console.Write("Май");
                    break;
                case 6:
                    Console.Write("Июнь");
                    break;
                case 7:
                    Console.Write("Июль");
                    break;
                case 8:
                    Console.Write("Август");
                    break;
                case 9:
                    Console.Write("Сентябрь");
                    break;
                case 10:
                    Console.Write("Октябрь");
                    break;
                case 11:
                    Console.Write("Ноябрь");
                    break;
                case 12:
                    Console.Write("Декабрь");
                    break;
                default:
                    Console.Write("Такого месяца нет");
                    break;
            }
            Console.ReadKey();
        }
    }
}
